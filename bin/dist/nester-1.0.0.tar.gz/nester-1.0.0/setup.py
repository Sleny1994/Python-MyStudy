from distutils.core import setup

setup(
    name         = 'nester',
    version      = '1.0.0',
    py_modules   = ['nester'],
    author       = 'sleny',
    author_email = 'sleny@qq.com',
    url          = 'http://www.zlcode.pub',
    description  = 'A simple printer of nested lists',)